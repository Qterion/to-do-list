class Scorer:
    def add(self, x, y):
        return x + y