Install `Python` extension in VSCode.
Open `tests.py` and hit F5.